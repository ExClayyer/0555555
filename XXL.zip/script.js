document.addEventListener('DOMContentLoaded', function () {
    // Фильтры - раскрытие секций
    const filterTitles = document.querySelectorAll('.filter-title');
    filterTitles.forEach(title => {
        title.addEventListener('click', function () {
            const section = this.closest('.filter-section');
            section.classList.toggle('active');
        });
    });

    // Цвета - переключение активного класса
    const colors = document.querySelectorAll('.color-option');
    colors.forEach(circle => {
        circle.addEventListener('click', function () {
            this.classList.toggle('active');
        });
    });

    // Гамбургер меню
    const hamburger = document.getElementById('hamburger');
    const mainNav = document.getElementById('mainNav');

    if (hamburger && mainNav) {
        hamburger.addEventListener('click', function () {
            mainNav.classList.toggle('active');
            this.classList.toggle('active');
        });
    }

    // Сайдбар toggle для мобильных
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebarContent = document.getElementById('sidebarContent');

    if (sidebarToggle && sidebarContent) {
        sidebarToggle.addEventListener('click', function () {
            sidebarContent.classList.toggle('active');
            this.classList.toggle('active');
        });
    }
});