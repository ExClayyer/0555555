document.addEventListener('DOMContentLoaded', function () {
    const filterTitles = document.querySelectorAll('.filter-title');
    filterTitles.forEach(title => {
        title.addEventListener('click', function () {
            const section = this.closest('.filter-section');
            section.classList.toggle('active');
        })
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const colors = document.querySelectorAll('.color-option');
    colors.forEach(circle => {
        circle.addEventListener('click', function () {
            this.classList.toggle('active');
        });
    });
});
