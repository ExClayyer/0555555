document.addEventListener('DOMContentLoaded', function () {
    const colors = document.querySelectorAll('.color-option');

    colors.forEach(circle => {
        circle.addEventListener('click', function () {
            colors.forEach(c => c.classList.remove('active'));
            this.classList.add('active');
        });
    });
});
const pics = [
    "https://cdn.kanzler-style.ru/upload/resize_cache/iblock/b39/1063_1598_2/dzzkp516kisup6776wqakmcmzd1t7c2u.JPG",
    "https://cdn.kanzler-style.ru/upload/resize_cache/iblock/578/1063_1598_2/u3v31aslzpgjphwyr5w43x4ljmyxw9d0.JPG",
    "https://cdn.kanzler-style.ru/upload/resize_cache/iblock/02e/1063_1598_2/rlaq9skprnot5z9tuzk4mwk6nznfqquj.JPG"
]
const big = document.getElementById("main-image")
const mini = document.querySelectorAll(".tumbnail")

document.addEventListener("DOMContentLoaded", function () {

    const big = document.getElementById("main-image").querySelector("img");
    const mini = document.querySelectorAll(".thumbnail");

    for (let i = 0; i < mini.length; i++) {
        mini[i].onclick = function () {

            mini.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            const newSrc = this.querySelector("img").src;
            big.src = newSrc;

        }
    }
});