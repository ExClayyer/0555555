document.addEventListener('DOMContentLoaded', function () {
    const colors = document.querySelectorAll('.color-option');

    colors.forEach(circle => {
        circle.addEventListener('click', function () {
            colors.forEach(c => c.classList.remove('active'));
            this.classList.add('active');
        });
    });
});
