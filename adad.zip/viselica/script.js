const answer = document.getElementById('guessField');
const submit = document.getElementById('guessSubmit');
const guessDisplay = document.getElementById('guesses');
const lastRes = document.getElementById('lastResult');
const lowHi = document.getElementById('lowOrHi');
const img = document.getElementById('status');
const newGame = document.getElementById('newGemza');
const tableGame = document.getElementById('gameTable');
const tableValues = document.querySelector('#gameTable tbody');
const audioLose = new Audio('lose.mp3');
const audioWin = new Audio('win.mp3')

let GRN = 0;
let guessesCount = 0;
let guessHist = [];
let gameStatus = 0;
let gameStatuses = ['Победа', 'Проиграл'];
submit.disabled = true;
tableGame.style.display = 'none'; 
function updateStyle() {
    if (submit.disabled) {
        submit.style.background = 'black';
        submit.style.cursor = 'not-allowed';
    } else {
        submit.style.background = 'linear-gradient(135deg, #66bb6a, #43a047)';
        submit.style.cursor = 'pointer';
    }
}
updateStyle();

function Gemza() {
    GRN = Math.floor(Math.random() * 100) + 1;
    guessesCount = 5;
    guessHist = [];
    img.src = 'imgs/5.jpg';
    lowHi.textContent = '';
    guessDisplay.textContent = '';
    lastRes.textContent = '';
    submit.disabled = false;
    console.log(GRN);
    guessDisplay.textContent = `Попыток : ${guessesCount}`;
    updateStyle();
}

function checkGuess() {
    const val = Number(answer.value);
    if (val === GRN) {
        img.src = 'imgs/WIN.jpg';
        lastRes.textContent = 'Поздравляем! Вы угадали!';
        lowHi.textContent = '';
        gameStatus = 0;
        endGame();
        audioWin.play();
    } else if (guessesCount === 1) {
        img.src = 'imgs/lose.jpg';
        lastRes.textContent = 'Игра окончена! Загаданное число: ' + GRN;
        guessDisplay.textContent = `Попыток осталось: ${0}`;
        lowHi.textContent = '';
        submit.disabled = true;
        gameStatus = 1;
        endGame();
        audioLose.play();
        submit.disabled = true;
        updateStyle();
    } else {
        guessesCount--;
        guessDisplay.textContent = `Попыток осталось: ${guessesCount}`;
        guessHist.push(val);
        lastRes.textContent = 'Ваши числа: ' + guessHist.join(', ');
        img.src = `imgs/${guessesCount}.jpg`;
        if (val > GRN) {
            lowHi.textContent = `Меньше`;
        } else {
            lowHi.textContent = `Больше`;
        }
    }
}

function endGame() {
    submit.disabled = true;
    addResultToTable();
    tableGame.style.display = 'table';
}

function addResultToTable() {
    const row = document.createElement('tr');
    row.innerHTML = `
        <td>${6 - guessesCount}</td>
        <td>${GRN}</td>
        <td>${gameStatuses[gameStatus]}</td>
    `;
    tableValues.appendChild(row);
}
submit.addEventListener('click', checkGuess);
newGame.addEventListener('click', Gemza);

answer.addEventListener('input', function() {
    answer.value = answer.value.replace(/[^0-9]/g, '');
    if (Number(answer.value) > 100) {
        answer.value = 100;
    } else if(Number(answer.value) < 1){
        answer.value = 1;
    }
});
