const table = document.getElementById('chess-table');
const chessBlock = document.querySelector('.chess-block');
const rows = table.querySelectorAll('tr')
const cols = table.querySelectorAll('td')
const figures = chessBlock.children;
const peshka = figures[5];
const king = figures[4];
const queen = figures[3];
const eleph = figures[2];
const rook = figures[1];
const horse = figures[0];
const answ = document.getElementById('answer');
const alph = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']
//покраска доски
for (let rowI = 0; rowI < 8; rowI++) {
    const tr = table.rows[rowI];
    for (let colI = 0; colI < 8; colI++) {
        const td = tr.cells[colI];
        td.style.width = '40px';
        td.style.height = '40px';
        const isLight = (rowI + colI) % 2 === 0;
        td.style.backgroundColor = isLight ? '#d8b779ff' : '#816d52ff';
    }
}

//функция для расстановки фигур
function placeFigure(col, row, figure, isBlack = true) {
    const clone = figure.cloneNode(true);
    const color = isBlack ? '' : 'brightness(0) saturate(100%) invert(1)';
    clone.style.filter = color;
    table.rows[row - 1].cells[col - 1].appendChild(clone);

}
//кони
placeFigure(2, 1, horse, true);
placeFigure(7, 1, horse, true);
placeFigure(2, 8, horse, false);
placeFigure(7, 8, horse, false);
//слоны
placeFigure(6, 8, eleph, false);
placeFigure(3, 8, eleph, false);
placeFigure(6, 1, eleph, true);
placeFigure(3, 1, eleph, true);
//ладья
placeFigure(8, 8, rook, false);
placeFigure(1, 8, rook, false);
placeFigure(8, 1, rook, true);
placeFigure(1, 1, rook, true);
//король+королева
placeFigure(5, 1, king, true)
placeFigure(5, 8, king, false)
placeFigure(4, 1, queen, true)
placeFigure(4, 8, queen, false)
//пешки
for (let i = 1; i < 9; i++) {
    placeFigure(i, 2, peshka, true)
    placeFigure(i, 7, peshka, false)
}
//указатели
const alphRow = document.createElement('tr');
table.prepend(alphRow);
const tr = table.rows[0];
tr.prepend('ㅤ');
for (let i = 0; i < 8; i++) {
    const alphs = document.createElement('td');
    alphs.textContent = `${alph[i]}`;
    alphRow.append(alphs);
    const numRow = document.createElement('td');
    numRow.textContent = `${i + 1}`;
    const tr = table.rows[i + 1];
    tr.prepend(numRow);
}
//подсчет элементов
let blackCount = 0;
function getElements() {
    const inputCount = document.querySelectorAll('input').length;
    const pCount = document.querySelectorAll('p').length;
    const tdCount = document.querySelectorAll('td').length;
    const liCount = document.querySelectorAll('li').length;
    for (let rowI = 0; rowI < 8; rowI++) {
        const tr = table.rows[rowI];
        for (let colI = 0; colI < 8; colI++) {
            const td = tr.cells[colI];
            if ((rowI + colI) % 2 === 0) {
                blackCount++;
            }
        }
    }
    const result = 'input: ' + inputCount + '<br>' +
        'p: ' + pCount + '<br>' +
        'td: ' + tdCount + '<br>' +
        'li: ' + liCount + '<br>' +
        'черные клетки: ' + blackCount;
    answ.innerHTML = result;
}
//списки
const ul = document.createElement('ul');

for (let i = 0; i < 5; i++) {
    const li = document.createElement('li');
    li.textContent = `Элемент уровня 1.${i + 1}`;
    li.style.color = 'black';
    if (i === 1 || i === 3) {
        const ULs = document.createElement('ul');
        for (let j = 0; j < 4; j++) {
            const Lis = document.createElement('li');
            Lis.textContent = `Вложенный элемент ${j + 1}`;
            Lis.style.backgroundColor = '#c5c5c5ff';
            ULs.appendChild(Lis);
        }
        if (i === 3) {
            ULs.style.display = 'none';
        }
        li.appendChild(ULs);
    }
    ul.appendChild(li);
}
document.body.appendChild(ul);