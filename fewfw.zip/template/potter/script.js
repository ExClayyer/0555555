const API_BASE = 'https://potterapi-fedeperin.vercel.app/en';


const contentEl = document.getElementById('content');
const btnBooks = document.getElementById('btn-books');
const btnCharacters = document.getElementById('btn-characters');
const btnHouses = document.getElementById('btn-houses');

let currentView = 'books';

async function fetchBooks() {
    const res = await fetch(`${API_BASE}/books`);
    const books = await res.json();
    renderBooks(books);
}

function renderBooks(books) {
    contentEl.innerHTML = '';
    books.forEach(book => {
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
      <h3>${book.title}</h3>
      <p><strong>Release date :</strong> ${book.releaseDate}</p>
      <p><em>${book.description}</em></p>
      <img src='${book.cover}'>
      <p><strong>Pages</strong>: ${book.pages}</p>`;
        contentEl.appendChild(card);
    });
}

async function fetchCharacters() {
    const res = await fetch(`${API_BASE}/characters`);
    const characters = await res.json();
    renderCharacters(characters);
}

function renderCharacters(chars) {
    contentEl.innerHTML = '';
    chars.forEach(char => {
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
      <h3>${char.fullName} (${char.nickname})</h3>
      <img src='${char.image}'>
      <p>Birth date ${char.birthdate}</p>
      <p>${char.hogwartsHouse}</p>
      <p>Children : ${char.children} </p>
      <p>Interpreted by ${char.interpretedBy}</p>
    `;
        contentEl.appendChild(card);
    });
}

async function fetchHouses() {
    const res = await fetch(`${API_BASE}/houses`);
    const houses = await res.json();
    renderHouses(houses);
}

function renderHouses(houses) {
    contentEl.innerHTML = '';
    houses.forEach(house => {
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
      <h3>${house.house}${house.emoji}</h3>
      <p><strong>Founder:</strong> ${house.founder}</p>
      <p><strong>Colors:</strong> ${house.colors}</p>
      <p><strong>Mascot:</strong> ${house.animal}</p>
    `;
        contentEl.appendChild(card);
    });
}

btnBooks.addEventListener('click', () => {
    if (currentView !== 'books') {
        currentView = 'books';
        fetchBooks();
    }
});

btnCharacters.addEventListener('click', () => {
    if (currentView !== 'characters') {
        currentView = 'characters';
        fetchCharacters();
    }
});

btnHouses.addEventListener('click', () => {
    if (currentView !== 'houses') {
        currentView = 'houses';
        fetchHouses();
    }
});

fetchBooks();