const answer = document.getElementById('guessField');
const inw = document.getElementById('inpw');
const submit = document.getElementById('guessSubmit');
const guessDisplay = document.getElementById('guesses');
const lastRes = document.getElementById('lastResult');
const lowHi = document.getElementById('lowOrHi');
const img = document.getElementById('status');
const newGame = document.getElementById('newGemza');
const tableGame = document.getElementById('gameTable');
const tableValues = document.querySelector('#gameTable tbody');
const audioLose = new Audio('lose.mp3');
const audioWin = new Audio('win.mp3')

let GRN = 0;
let guessesCount = 0;
let guessHist = [];
let gameStatus = 0;
let gameStatuses = ['Победа', 'Проиграл'];
guessDisplay.style.display = 'none';
submit.style.display = 'none';
tableGame.style.display = 'none';
inw.style.display = 'none';
answer.style.display = 'none';
img.style.display = 'none';

function Gemza() {
    GRN = Math.floor(Math.random() * 100) + 1;
    guessesCount = 5;
    guessHist = [];
    guessDisplay.style.display = '';
    img.src = 'imgs/5.jpg';
    lowHi.textContent = '';
    guessDisplay.textContent = '';
    lastRes.textContent = '';
    submit.disabled = false;
    submit.classList.remove('no-hover');
    console.log(GRN);
    submit.style.display='';
    guessDisplay.textContent = `Попыток осталось: ${guessesCount}`;
    answer.value=1;
    inw.style.display = '';
    answer.style.display = '';
    img.style.display = '';
    newGame.style.display = 'none'
}

function checkGuess() {
    const val = Number(answer.value);
    if (answer.value.trim() === '' || isNaN(val)) {
        alert('Пожалуйста, введите число от 1 до 100!');
        answer.focus();
        return;
    }
    if (val === GRN) {
        img.src = 'imgs/WIN.jpg';
        lastRes.textContent = 'Поздравляем! Вы угадали!';
        lowHi.textContent = '';
        gameStatus = 0;
        endGame();
        audioWin.play();
        newGame.style.display = ''
    } else if (guessesCount === 1) {
        img.src = 'imgs/lose.jpg';
        lastRes.textContent = 'Игра окончена! Загаданное число: ' + GRN;
        lowHi.textContent = '';
        submit.disabled = true;
        gameStatus = 1;
        endGame();
        audioLose.play();
        guessesCount--;
        guessDisplay.textContent = `Попыток осталось: ${guessesCount}`;
        submit.disabled = true;
        submit.classList.toggle('no-hover');
        newGame.style.display = ''
    } else {
        guessesCount--;
        guessHist.push(val);
        lastRes.textContent = 'Ваши числа: ' + guessHist.join(', ');
        guessDisplay.textContent = `Попыток осталось: ${guessesCount}`;
        img.src = `imgs/${guessesCount}.jpg`;
        if (val > GRN) {
            lowHi.textContent = `⬇️Меньше⬇️`;
        } else {
            lowHi.textContent = `⬆️Больше⬆️`;
        }
    }
}

function endGame() {
    submit.disabled = true;
    addResultToTable();
    tableGame.style.display = 'table';
}

function addResultToTable() {
    const row = document.createElement('tr');
    row.innerHTML = `
        <td>${6 - guessesCount}</td>
        <td>${GRN}</td>
        <td>${gameStatuses[gameStatus]}</td>
    `;
    tableValues.appendChild(row);
}
submit.addEventListener('click', checkGuess);
newGame.addEventListener('click', Gemza);

answer.addEventListener('input', function() {
    answer.value = answer.value.replace(/[^0-9]/g, '');
    let val = Number(answer.value);
    if (answer.value.length === 0) {
        return; 
    }
    if (val > 100) {
        answer.value = 100;
    } else if (val < 1) {
        answer.value = 1;
    }
});