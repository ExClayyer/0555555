const API_KEY = "c27c77ac-5d50-4023-986d-6b812923dc62";
const base_url = "https://api.templated.io/v1";
const rendersContainer = document.getElementById("rendersContainer");
const loadBtn = document.getElementById("loadRendersBtn");

async function getAllRenders() {
    const response = await fetch(`${base_url}/renders`, {
        method: "GET",
        headers: {
            Authorization: `Bearer ${API_KEY}`,
        },
    });
    const renders = await response.json();
    return renders;
}

function displayRenders(renders) {
    if (!Array.isArray(renders)) {
        const possibleArray = renders.data || renders.renders || renders.items || [];
        if (Array.isArray(possibleArray)) {
            renders = possibleArray;
        } else {
            renders = [];
        }
    }

    const html = renders
        .map(render => {
            const url = render.url || render.imageUrl || render.preview;
            if (!url) return '';
            return `<img src="${url}" alt="Render ${render.id}" style="width: 200px">`;
        })

    rendersContainer.innerHTML = html
}

loadBtn.addEventListener("click", async () => {
    rendersContainer.innerHTML = "<p style='font-size:200px; text-align:center ; color:#2428'>Загрузка...</p>";
    const renders = await getAllRenders();
    displayRenders(renders);
    var del = document.getElementById("loadRendersBtn");
    del.remove();
});