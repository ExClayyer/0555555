const imageContainer = document.querySelector('.image-container');
const container = document.querySelector('.container');
const input = document.querySelector('#input');
const answerP = document.querySelector('#answer');
const feedBtn = document.querySelector('#feed');
const sleepBtn = document.querySelector('#put-to-sleep');
const explodeBtn = document.querySelector('#explode');
const formBtn = document.querySelector('#btn-form');

const answers = {
  "привет": "привет",
  "как дела": "чудесно",
  "что делаешь": "беседую с тобой",
};

function feed() {
  imageContainer.style.backgroundPosition = "13% 01%";
  container.classList.add('container-feed');
  setTimeout(() => {
    imageContainer.style.backgroundPosition = "90% 0%";
    container.classList.remove('container-feed');
  }, 2000);
}

function putToSleep() {
  imageContainer.style.backgroundPosition = "85% 100%";
  container.classList.add('container-night');
  setTimeout(() => {
    imageContainer.style.backgroundPosition = "90% 0%";
    container.classList.remove('container-night');
  }, 5000);
}

function decideMathAnswer(text) {
  const data = text.replace('реши', '').trim();
  let result = eval(data);
  return result;
}

function washTomo() {
    const originalBackground = imageContainer.style.background;
    const originalPosition = imageContainer.style.backgroundPosition;
    imageContainer.style.background = 'url("images/boom-explosion.gif")';
    imageContainer.style.backgroundSize = 'cover';
    imageContainer.style.backgroundPosition = 'center';
    imageContainer.style.backgroundPosition = "85% 100%";
    container.classList.add('container-explode');
    setTimeout(() => {
        imageContainer.style.background = originalBackground;
        imageContainer.style.backgroundPosition = originalPosition;
        imageContainer.style.backgroundPosition = "90% 0%";
        container.classList.remove('container-explode');
    }, 1550)
}

function answerQuestion(text) {
  let answer = [];
  if (text.includes("реши")) {
    let a = decideMathAnswer(text);
    answerP.textContent = "Ответ: " + a;
    return;
  }
  for (let i of Object.entries(answers)) {
    if (text.includes(i[0])) {
        answer.push(i[1]);
      }
    }
  
  if (answer.length === 0) {
    answerP.textContent = "я не знаю как ответить";
    return;
  }
  answerP.textContent = answer.join(", ");
}

feedBtn.addEventListener('click', feed);
sleepBtn.addEventListener('click', putToSleep);
explodeBtn.addEventListener('click', washTomo);
formBtn.addEventListener('click', (e) => {
  e.preventDefault();
  answerQuestion(input.value.toLowerCase());
  input.value = '';
});

imageContainer.addEventListener('mouseenter', () => {
  imageContainer.style.backgroundPosition = "11% 100%";
});
imageContainer.addEventListener('mouseleave', () => {
  imageContainer.style.backgroundPosition = "90% 0%";
});