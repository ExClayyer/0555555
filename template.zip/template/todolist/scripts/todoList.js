const todoContainer = document.querySelector("#todo-list_container");
const todoInput = document.querySelector("#todoList-from_input");
const todoBtn = document.querySelector("#todoList-btn");

function getItems() {
    return JSON.parse(localStorage.getItem("todoList")) || [];
}

function setItems(todos) {
    localStorage.setItem("todoList", JSON.stringify(todos));
}

function createItemTodo(text) {
    if (!text) return;
    let li = document.createElement('LI');
    li.textContent = text;
    li.classList.add('todo-item');
    li.dataset.status = 'now';

    return li;
}

function appendItem(item) {
    todoContainer.append(item);
}

getItems().forEach(item => appendItem(createItemTodo(item)));

todoBtn.addEventListener("click", () => {
    let value = todoInput.value.trim();

    if (!value) return;

    let todos = getItems();
    if (todos.includes(value)) {
        alert("БЫЛО!")
        return;
    }

    todos.push(value);
    setItems(todos);
    appendItem(createItemTodo(value));
    todoInput.value = "";
})

todoContainer.addEventListener('click', (e) => {
    if (e.target.tagName !== "LI") return;
    e.target.dataset.status = e.target.dataset.status == "done" ? "now" : "done";
})