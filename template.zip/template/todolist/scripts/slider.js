const images = [
    {
        id: 1,
        src: '../img/1.png',
        alt: 'sora ai'
    },
    {
        id: 2,
        src: '../img/2.png',
        alt: '2'
    },
    {
        id: 3,
        src: '../img/3.png',
        alt: 'Чуваки'
    },
    {
        id: 4,
        src: '../img/4.png',
        alt: 'Как пацаны делают так и я делаю'
    },
    {
        id: 5,
        src: '../img/5.png',
        alt: 'Пиджачки'
    },
    {
        id: 6,
        src: '../img/6.png',
        alt: 'Кардиомагнил'
    }
]

const sliderImage = document.querySelector('#slider-img');
const btnPrev = document.querySelector('#slider-btn_prev');
const btnNext = document.querySelector('#slider-btn_next');

let currentIndex = 0 ; 
sliderImage.src = images[currentIndex].src;
sliderImage.alt = images[currentIndex].alt;


btnPrev.addEventListener("click", () => {
    --currentIndex;
    if (currentIndex < 0) {
        currentIndex = images.length - 1;
    }
    sliderImage.src = images[currentIndex].src;
    sliderImage.alt = images[currentIndex].alt;

})
btnNext.addEventListener("click", () => {
    ++currentIndex;
    if (currentIndex >= images.length) {
        currentIndex = 0;
    }
    sliderImage.src = images[currentIndex].src;
    sliderImage.alt = images[currentIndex].alt;
 
})
